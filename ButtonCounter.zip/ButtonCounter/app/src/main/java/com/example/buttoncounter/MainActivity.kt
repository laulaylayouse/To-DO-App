package com.example.buttoncounter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var TextView: TextView
    lateinit var Button_Sub: Button
    lateinit var Button_Add: Button

    private  var counter =1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        TextView=findViewById(R.id.TextView)

        Button_Sub=findViewById(R.id.Button_Sub)
        Button_Add=findViewById(R.id.Button_Add)


        Button_Sub.setOnClickListener {

            val sub = TextView.text.toString().toInt() - counter
            TextView.setText(sub.toString())
        }
        Button_Add.setOnClickListener {

            val sum = TextView.text.toString().toInt() + counter
            TextView.setText(sum.toString())
        }

    }
}
package com.example.todoapp_laila

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var items_text: ArrayList<String>
    private lateinit var items_checked: ArrayList<Boolean>
    private lateinit var num: ArrayList<Int>
    private lateinit var Recycler_View_item: RecyclerView
    private lateinit var Floating_Action_Button: FloatingActionButton
    lateinit var  Check_Box: CheckBox
    private lateinit var rvAdapter: RVAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title="To DO App"

        items_text = arrayListOf()
        items_checked = arrayListOf()

        Recycler_View_item = findViewById(R.id.Recycler_View_item)
        Recycler_View_item.adapter = RVAdapter(this, items_text, items_checked)
        Recycler_View_item.layoutManager = LinearLayoutManager(this)

        Floating_Action_Button = findViewById(R.id.Floating_Action_Button)
        Floating_Action_Button.setOnClickListener {

            val dialogBuilder = AlertDialog.Builder(this)

            val layout = LinearLayout(this)
            layout.orientation = LinearLayout.VERTICAL

            val To_DO_item = EditText(this)
            To_DO_item.hint = "Enter To DO item"
            layout.addView(To_DO_item)

            dialogBuilder.setPositiveButton("ADD", DialogInterface.OnClickListener {
                    dialog, id ->
                run {
                    items_text.add(To_DO_item.text.toString())
                    items_checked.add(false)
                }
            })
                .setNegativeButton("CANCEL", DialogInterface.OnClickListener {
                        dialog, id -> dialog.cancel()
                })

            val alert = dialogBuilder.create()
            alert.setTitle("New Item")
            alert.setView(layout)
            alert.show()

        }

        num = arrayListOf()


    }

    fun onCheckboxClicked(view: View) {
        if (view is CheckBox) {
            val checked: Boolean = view.isChecked
            items_checked.add(checked)

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var items_Deleted = 0
        var count =0
        for(i in items_checked){
            if(i == true)
            {
                num.add(count)
                items_checked.removeAt(count)
                items_text.removeAt(count)
                Recycler_View_item.adapter?.notifyDataSetChanged()

                items_Deleted++
            }
            count++
        }

        if(items_Deleted > 0){
            Toast.makeText(this, "$items_Deleted items deleted", Toast.LENGTH_LONG).show()
        }else{
            Toast.makeText(this, "No items selected", Toast.LENGTH_LONG).show()
        }
        return super.onOptionsItemSelected(item)
    }

}
package com.example.todoapp_laila

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_row.view.*


class RVAdapter (val context: Context, val text: ArrayList<String>, val checked: ArrayList<Boolean>):
RecyclerView.Adapter<RVAdapter.MessageViewHolder>() {
    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        return MessageViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.item_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.itemView.apply {
            TextView_item.text= text[position]
            Check_Box.isChecked = checked[position]
            Check_Box.setOnCheckedChangeListener{ _, isChecked ->
                if(isChecked)
                {
                    TextView_item.setTextColor(Color.WHITE)
                }else
                {
                    TextView_item.setTextColor(Color.BLACK)
                }

                checked[position]= !checked[position]
            }
        }
    }

    override fun getItemCount()= text.size

}